function externalFunc() {
    document.getElementById("demo").innerHTML = "Paragraph changed from external file.";
}